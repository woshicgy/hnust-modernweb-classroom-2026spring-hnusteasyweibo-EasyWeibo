<template>
  <div>
    <div class="nav">
      <router-link to="/">首页</router-link>
      <router-link to="/publish">发布</router-link>
      <router-link to="/profile">我的</router-link>
    </div>
    <div class="container">
      <router-view />
    </div>
  </div>
</template>