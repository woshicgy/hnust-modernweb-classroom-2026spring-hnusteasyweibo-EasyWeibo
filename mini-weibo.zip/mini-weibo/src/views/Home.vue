<template>
  <div>
    <h3>首页 | 动态</h3>
    <div
      v-for="(post, index) in postList"
      :key="index"
      class="card"
      style="margin-top:15px;padding:10px;border:1px solid #eee;border-radius:8px"
    >
      <!-- 动态内容 -->
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <p style="margin:0">{{ post.content }}</p>
        <!-- 删除按钮 -->
        <button
          @click="delPost(index)"
          style="background:#ff4d4f;color:white;border:none;border-radius:4px;padding:3px 8px;font-size:12px;cursor:pointer"
        >
          删除
        </button>
      </div>

      <img
        v-if="post.img"
        :src="post.img"
        style="width:100%;border-radius:8px;margin:8px 0"
      />

      <!-- 点赞：只能点一次 -->
      <div style="margin:8px 0;display:flex;align-items:center">
        <span
          @click="likePost(index)"
          :style="{
            cursor: post.liked ? 'default' : 'pointer',
            fontSize:'20px',
            color: post.liked ? '#e74c3c' : '#999'
          }"
        >❤️</span>
        <span style="margin-left:4px">{{ post.like }}</span>
      </div>

      <!-- 评论输入 -->
      <div style="margin-top:10px">
        <input
          v-model="newComment[index]"
          placeholder="写评论..."
          style="width:calc(100% - 70px);padding:6px"
          @keyup.enter="addComment(index)"
        />
        <button @click="addComment(index)" style="margin-left:5px;padding:6px 10px">发送</button>
      </div>

      <!-- 评论列表 -->
      <div v-if="post.comments.length > 0" style="margin-top:8px;padding-left:8px;border-left:2px solid #ccc">
        <div v-for="(c, i) in post.comments" :key="i" style="margin:4px 0;font-size:14px">
          {{ c }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'

const postList = ref([])
const newComment = ref({})

// 读取本地存储
onMounted(() => {
  const data = localStorage.getItem('postList')
  if (data) {
    postList.value = JSON.parse(data)
  }
})

// 深度监听：点赞、评论、删除自动保存
watch(postList, () => {
  localStorage.setItem('postList', JSON.stringify(postList.value))
}, { deep: true })

// 点赞：同一个动态只能点赞1次
function likePost(index) {
  const item = postList.value[index]
  if (item.liked) return // 已经点过，不响应
  item.like++
  item.liked = true 
}

// 发评论
function addComment(index) {
  const txt = newComment.value[index]?.trim()
  if (!txt) return
  postList.value[index].comments.push(txt)
  newComment.value[index] = ''
}

// 删除动态
function delPost(index) {
  if (confirm('确定删除这条动态？')) {
    postList.value.splice(index, 1)
  }
}
</script>