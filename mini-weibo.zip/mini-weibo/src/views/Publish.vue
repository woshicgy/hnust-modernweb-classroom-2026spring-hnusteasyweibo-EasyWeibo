<template>
  <div class="card">
    <h3>发布动态</h3>

    <!-- 文字内容 -->
    <textarea
      v-model="content"
      placeholder="想说点什么..."
      style="width: 100%; height: 100px; margin-top: 10px"
    ></textarea>

    <!-- 图片选择 -->
    <div style="margin-top: 10px">
      <label>选择图片：</label>
      <input type="file" accept="image/*" @change="onFileChange" />
    </div>

    <!-- 图片预览 -->
    <div v-if="imgUrl" style="margin-top: 10px">
      <p>预览：</p>
      <img :src="imgUrl" style="max-width: 100%; max-height: 250px; border-radius: 8px" />
    </div>

    <button @click="publish" style="margin-top: 12px">发布</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const content = ref('')
const imgUrl = ref('')

// 选择图片
function onFileChange(e) {
  const file = e.target.files[0]
  if (!file) return
  const reader = new FileReader()
  reader.readAsDataURL(file)
  reader.onload = () => {
    imgUrl.value = reader.result
  }
}

// 发布
function publish() {
  if (!content.value) return alert('请输入内容')

  let list = JSON.parse(localStorage.getItem('postList') || '[]')
  list.unshift({
    content: content.value,
    // 替换成指定的默认图
    img: imgUrl.value || 'https://bpic.588ku.com/back_origin_min_pic/25/01/21/49d86069aac555b9f2f9bc6be1b24087.jpg!/fh/300/quality/90/unsharp/true/compress/true',
    like: 0,
    comments: []
  })

  localStorage.setItem('postList', JSON.stringify(list))
  alert('发布成功！')
  router.push('/')
}
</script>