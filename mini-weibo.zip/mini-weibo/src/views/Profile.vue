<template>
  <div class="card">
    <h3>个人中心</h3>
    <div style="margin-top:10px">
      <label>用户名：</label>
      <input v-model="user.name" style="width:100%" />
    </div>
    <div style="margin-top:10px">
      <label>简介：</label>
      <input v-model="user.intro" style="width:100%" />
    </div>
    <button @click="save" style="margin-top:10px">保存修改</button>
  </div>
</template>

<script setup>
import { reactive, onMounted } from 'vue'

const user = reactive({
  name: '',
  intro: ''
})

onMounted(() => {
  const name = localStorage.getItem('userName') || '用户001'
  const intro = localStorage.getItem('userIntro') || '无'
  user.name = name
  user.intro = intro
})

function save() {
  localStorage.setItem('userName', user.name)
  localStorage.setItem('userIntro', user.intro)
  alert('保存成功！')
}
</script>